# Juno-DKT
Scikit-learn style implementation of Deep Knowledge Tracing models based on pytorch.